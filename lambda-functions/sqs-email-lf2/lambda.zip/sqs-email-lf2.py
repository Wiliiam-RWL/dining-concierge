import os
from datetime import datetime
from urllib.request import Request, urlopen
import json
import boto3
import requests

SQS_URL = os.environ["sqs"]
OPEN_SEARCH_URL = os.environ["open_search"]
INDEX = os.environ["os_index"]
OS_USER = os.environ["os_user"]
OS_PWD = os.environ["os_pwd"]


def poll_sqs(event):
    print("Polling message from {} at {}...".format(SQS_URL, event["time"]))
    sqs_client = boto3.client("sqs")
    kwargs = {"QueueUrl": SQS_URL, "MaxNumberOfMessages": 1}
    try:
        response = sqs_client.receive_message(**kwargs)
        print(response)
        if response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            messages = response.get("Messages", None)
            if messages is not None:
                queries = []
                for message in messages:
                    body = json.loads(message["Body"])
                    queries.append(body)
                return queries, True
            else:
                print("NOTHING From SQS!")
                return None, False
        else:
            print("BAD RESPONSE!")
            print(response)
            return None, False
    except:
        print("ERROR FROM OPENSEARCH!")
        return None, False


def open_search_query(queries):
    headers = {"Content-Type": "application/json"}
    for query in queries:
        body = {
            "query": {
                "fuzzy": {
                    "categories": {
                        "value": f"{query['cuisine']}",
                        "fuzziness": "AUTO",  # Adjust fuzziness as needed
                    }
                }
            }
        }
        response = requests.get(
            url=f"{OPEN_SEARCH_URL}/{INDEX}/_search",
            auth=(OS_USER, OS_PWD),
            headers=headers,
            data=json.dumps(body),
        )
        if response.status_code == 200:
            print("SUCCESS QUERY")
            print(response)
        else:
            print("ERROR QUERY")
            print(response)

def lambda_handler(event, context):
    quries, success = poll_sqs(event=event)
    if success:
        print(quries)
        print("Check complete at {}".format(str(datetime.now())))
    else:
        print("FAILED polling messages!")
